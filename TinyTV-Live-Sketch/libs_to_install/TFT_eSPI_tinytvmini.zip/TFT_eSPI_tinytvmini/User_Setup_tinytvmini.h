#define SSD1357_DRIVER

#define TFT_WIDTH  64
#define TFT_HEIGHT 64


#define RP2040_PIO_SPI // Leave commented out to use standard RP2040 SPI port interface

#define TFT_MOSI 6 // In some display driver board, it might be written as "SDA" and so on.
#define TFT_SCLK 7
#define TFT_CS   8  // Chip select control pin
#define TFT_DC   5  // Data Command control pin
#define TFT_RST  4  // Reset pin (could connect to Arduino RESET pin)
#define TFT_BL   -1  // LED back-light

#define SPI_FREQUENCY  50000000


#define LOAD_GLCD   // Font 1. Original Adafruit 8 pixel font needs ~1820 bytes in FLASH

// Comment out the #define below to stop the SPIFFS filing system and smooth font code being loaded
// this will save ~20kbytes of FLASH
#define SMOOTH_FONT
