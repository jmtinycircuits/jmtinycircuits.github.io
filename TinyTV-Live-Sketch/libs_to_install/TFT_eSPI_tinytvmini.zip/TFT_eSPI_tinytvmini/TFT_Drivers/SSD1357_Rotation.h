
// This is the command sequence that rotates the SSD1351 driver coordinate frame

  rotation = m % 4; // Limit the range of values to 0-3

  uint8_t madctl = 0x60;

  switch (rotation) {
    case 0:
      madctl |= 0x12;
      _width  = _init_width;
      _height = _init_height;
      colstart=0x20;
      rowstart=0;
      break;
    case 1:
      madctl |= 0x11;
      _width  = _init_height;
      _height = _init_width;
      colstart=0x20;
      rowstart=0;
      break;
    case 2:
      madctl |= 0x00;
      _width  = _init_width;
      _height = _init_height;
      colstart=0x20;
      rowstart=0;
      break;
    case 3:
      madctl |= 0x03;
      _width  = _init_height;
      _height = _init_width;
      colstart=0x20;
      rowstart=0;
      break;
  }
  

  
  writecommand(0xA0); // SETREMAP
  writedata(madctl);
  writedata(0x00);
  //writecommand(0xA1); // STARTLINE
  //writedata(rotation < 2 ? TFT_HEIGHT : 0);
  //writedata(0);
  //writecommand(0xA2);
  //writedata(0x40);
